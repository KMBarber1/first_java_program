public class Test {
    public static void main(String[] args) {
        System.out.println("My name is Kate Barber");
        System.out.println("I am so many years old");
        System.out.println("My hometown is Phoenix, AZ");
    }
}